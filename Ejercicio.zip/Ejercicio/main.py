from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Inicializamos la aplicación
app = FastAPI()

# Configuración de CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 1. Diccionario de usuarios (Estructura de datos)
usuarios_db = {
    "carlos": "clave123",
    "ana": "secreto456",
    "luis": "python2026"
}

# Modelos de validación con Pydantic
class LoginData(BaseModel):
    usuario: str
    contrasena: str

class FrutasData(BaseModel):
    opciones: list[str]

# --- RUTA 1: LOGIN ---
@app.post("/login")
def login(data: LoginData):
    usuario_db = usuarios_db.get(data.usuario.lower())
    
    # Estructura 1: Operador ternario (if/else en una línea)
    status_check = "Sistema verificado" if usuario_db else "Usuario no encontrado"
    print(f"Estado de verificación interna: {status_check}")

    # Estructura 2: if / elif / else
    if data.usuario.lower() == "mantenimiento" and data.contrasena == "admin":
        print("Acceso especial de mantenimiento activado.")
        return {"mensaje": "Acceso especial de mantenimiento"}
        
    elif usuario_db and usuario_db == data.contrasena:
        return {"mensaje": "Login exitoso", "estado_verificacion": status_check}
        
    else:
        raise HTTPException(status_code=401, detail="Usuario o contraseña incorrectos")


# --- RUTA 2: PREPARAR ENSALADA ---
@app.post("/preparar")
def preparar_ensalada(data: FrutasData):
    
    if len(data.opciones) != 3:
        raise HTTPException(status_code=400, detail="Debes elegir exactamente 3 frutas")
    
    ensalada = []
    
    # Estructura 3: try / except
    try:
        for opcion in data.opciones:
            # Estructura 4: match / case
            match opcion:
                case "1":
                    ensalada.append("Manzana")
                case "2":
                    ensalada.append("Banano")
                case "3":
                    ensalada.append("Fresa")
                case "4":
                    ensalada.append("Mango")
                case "5":
                    ensalada.append("Uvas")
                
                # Estructura 5: break
                case "0":
                    print(f"Pedido cancelado por el usuario al elegir la opción {opcion}")
                    ensalada = [] 
                    break 
                
                case _:
                    # Forzamos un error si la opción no es válida
                    raise ValueError(f"La opción {opcion} no es válida.")

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error interno del servidor: {str(e)}")

    # Verificamos si la ensalada fue cancelada o completada
    if not ensalada:
         return {"mensaje": "Preparación de ensalada cancelada."}
    else:
        return {"mensaje": f"¡Ensalada lista! Contiene: {ensalada[0]}, {ensalada[1]} y {ensalada[2]}."}